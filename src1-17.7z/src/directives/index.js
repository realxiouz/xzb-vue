import disabled from './input-disabled';
import position from './input-position';

export default {
    disabled,
    position,
};
