export const SET_BREADCRUMBS = 'SET_BREADCRUMBS';

export const SET_AGENTS_BASE_LIST = 'SET_AGENTS_BASE_LIST';

export const SET_USER_AVATAR = 'set_user_avatar';
export const SET_USER_NICKNAME = 'set_user_nickname';
export const SET_USER_TOKEN = 'set_user_token';

export const CHOOSE_LOGIN = 'choose_login';
