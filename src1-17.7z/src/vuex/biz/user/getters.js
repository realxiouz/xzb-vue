
// const agentsbaseList = state => state.agentsbaseList || {};
const nickname = state => state.nickname || '';
const avatar = state => state.avatar || '';
const token = state => state.token || '';
const isLogin = state => state.isLogin || 1;
export default {
    // agentsbaseList,
    nickname,
    avatar,
    token,
    isLogin
};
