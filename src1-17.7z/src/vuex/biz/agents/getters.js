
const agentsbaseList = state => state.agentsbaseList || {};

export default {
    agentsbaseList,
};
