const regionList = state => state.regionList;

export default {
    regionList,
};
