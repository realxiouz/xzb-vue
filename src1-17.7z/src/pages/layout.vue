<template>
  <div id="app">
    <page-head></page-head>
    <banner class="hidden-sm-and-down"></banner>
    <router-view/>
    <page-foot></page-foot>
  </div>
</template>

<script>
import PageHead from '@/pages/header/index';
import PageFoot from '@/pages/footer';
import Banner from '@/pages/bannerbar';
export default {
    name: 'app',
    components:{
      PageHead,PageFoot,Banner
    }
};
</script>

<style lang="scss">
@import 'element-ui/lib/theme-chalk/display.css';
#app {
    /* font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px; */
    background-color: #f6f6f6;
    label {
          margin-bottom: 0;
    }

    .el-form--label-top .el-form-item__label{
      padding: 0px;
    }
    //上传slot高度限制
    .el-form-item__content{
      // line-height: 14px;
    }
    .el-message{
      min-width: 280px;
    }

}
</style>
