<template>
    <div id="bannerContainer">

    </div>
</template>

<style lang="scss" scoped>
    #bannerContainer{
        width: 100%;
        height: 100px;
        background-image: url(../../assets/sy_topbg.jpg);
    }
</style>

