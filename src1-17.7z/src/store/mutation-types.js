export const RECORD_USERINFO = 'RECORD_USERINFO';
export const GET_USERINFO = 'GET_USERINFO';
export const OUT_LOGIN = 'OUT_LOGIN';
export const SET_MSG_COUNT = 'SET_MSG_COUNT';
export const SET_CART_COUNT = 'SET_CART_COUNT';

